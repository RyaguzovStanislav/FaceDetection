from typing import Any

from detection.common.providers import OnlyDocFilesProvider
from detection.detect.faces import DetectFaces
from detection.common.base import T_FILE


class Runner:

    def run(self) -> Any:
        pass


class MainRunner(Runner):

    def __init__(self, dir_in: T_FILE):
        self.__dir_in = dir_in

    def run(self):
        for file_path in OnlyDocFilesProvider(path_in=self.__dir_in).get():
            detect_image = DetectFaces().detect_faces(file_path)
        return detect_image